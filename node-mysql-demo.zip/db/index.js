/*
 * @Author: hanmingda
 * @Date: 2022-07-21 16:59:15
 * @LastEditors: hanmingda
 * @LastEditTime: 2022-07-27 16:18:29
 * @Description:
 * @FilePath: \node-mysql-demo\db\index.js
 */
let mysql = require("mysql");

let db = mysql.createPool({
  host: "127.0.0.1", //数据库IP地址
  user: "root", //数据库登录账号
  password: "root", //数据库登录密码
  database: "node_database", //要操作的数据库
});

module.exports = db;
