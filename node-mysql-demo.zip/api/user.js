/*
 * @Author: hanmingda
 * @Date: 2022-07-21 17:00:52
 * @LastEditors: hanmingda
 * @LastEditTime: 2022-07-27 10:56:01
 * @Description: 
 * @FilePath: \node-mysql-demo\api\user.js
 */
let db = require('../db');

// 获取用户列表
exports.list = (req, res) => {
  const { query } = req;
  const page = query.page || 1;
  const limit = query.limit || 10;
  var sqlByLimit = `select * from user WHERE deleteTime is null limit ${(page - 1) * limit}, ${limit}`;
  const sendData = {};
  db.query(sqlByLimit, (err, data) => {
    if(err) {
      return res.send('错误：' + err.message)
    }
    sendData.list = data;
  })
  
  var sqlTotal = 'select count(*) as total from user WHERE deleteTime is null';
  db.query(sqlTotal, (err, data) => {
    if(err) {
      return res.send('错误：' + err.message)
    }
    sendData.total = data[0].total;
  })

  setTimeout(() => {
    res.send(sendData)
  }, 1000)

}

// 增加用户
exports.add = (req, res) => {
  const { body } = req;
  const { nickname, avatar, sex, account, password } = body;
  const sql = `insert into user (nickname, avatar, sex, account, password, createTime, createTimeUnix) values ('${nickname}', '${avatar}', '${sex}', '${account}', '${password}', CURRENT_TIMESTAMP(), UNIX_TIMESTAMP())`;
  db.query(sql, (err, data) => {
    if(err) {
      return res.send({
        code: 1,
        msg: '错误：' + err.message
      })
    }
    res.send({
      code: 0,
      msg: "添加成功",
    })
  })
}

// 修改用户
exports.update = (req, res) => {
  const { body } = req;
  const { id, nickname, avatar, sex, account, password } = body;
  const sql = `update user set nickname = '${nickname}', avatar = '${avatar}', sex = '${sex}', account = '${account}', password = '${password}' where id = '${id}'`;
  db.query(sql, (err, data) => {
    if (err) {
      return res.send({
        code: 1,
        msg: '错误：' + err.message
      })
    }
    res.send({
      code: 0,
      msg: "修改成功",
    })
  })
}

// 删除用户
exports.delete = (req, res) => {
  const { body } = req;
  const { id } = body;
  const sql = `update user set deleteTime = UNIX_TIMESTAMP() where id = '${id}'`;
  db.query(sql, (err, data) => {
    if (err) {
      return res.send({
        code: 1,
        msg: '错误：' + err.message
      })
    }
    res.send({
      code: 0,
      msg: "删除成功",
    })
  })
}