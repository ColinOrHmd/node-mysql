/*
 * @Author: hanmingda
 * @Date: 2022-07-26 08:45:22
 * @LastEditors: hanmingda
 * @LastEditTime: 2022-07-26 08:52:01
 * @Description:
 * @FilePath: \node-mysql-demo\api\file.js
 */
const formidable = require('formidable');

// 上传图片
exports.uploadImg = (req, res) => {
  //创建formidable表单解析对象
	const form = new formidable.IncomingForm();
  //保留上传文件的后缀名字
	form.keepExtensions = true;
  //设置上传文件的保存路径
  form.uploadDir = "./public/upload";
  //解析客户端传递过来的formData对象
  form.parse(req, (err, fields, files) => {
    if (err) {
      res.json({
        status: "1",
        msg: err.message,
      });
      return;
    }
    let oldPath = files.file.path;
    let newPath = "./public/upload/" + files.file.name;
    fs.rename(oldPath, newPath, (err) => {
      if (err) {
        res.json({
          status: "1",
          msg: err.message,
        });
        return;
      }
      res.json({
        status: "0",
        msg: "success",
        result: {
          imgUrl: "http://localhost:8080/upload/" + files.file.name,
        },
      });
    });
  });
};
